// eslint-disable-next-line @typescript-eslint/no-unused-vars
import React from 'react';
import DataTanamanForm from './DataTanamanForm';

export default function TambahStatistik() {
  return <DataTanamanForm type="add" />;
}
