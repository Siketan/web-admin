// eslint-disable-next-line @typescript-eslint/no-unused-vars
import React from 'react';
import TokoTaniForm from './TokoTaniForm';

export default function DetailTokoTani() {
  return <TokoTaniForm type="detail" />;
}
