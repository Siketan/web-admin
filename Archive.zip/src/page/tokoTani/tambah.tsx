// eslint-disable-next-line @typescript-eslint/no-unused-vars
import React from 'react';
import TokoTaniForm from './TokoTaniForm';

export default function TambahTokoTani() {
  return <TokoTaniForm type="add" />;
}
